module.exports = {
  bot: {
   owners: ["561855812922900512"],// owners id
    clientSECRET:  process.env.sec, // Client Secret
    TOKEN: process.env.token,
    prefix : "&",
    invite: "https://discord.com/api/oauth2/authorize?client_id=743226920795242566&permissions=8&scope=bot",
    category : "854494376888893470",
    transfering : "561855812922900512",
    price : "100",
  },
  website: {
    PORT: "3001",//website port
  }
}